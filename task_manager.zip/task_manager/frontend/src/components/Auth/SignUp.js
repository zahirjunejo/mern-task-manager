import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";
import AccountCircleIcon from "@mui/icons-material/AccountCircle";
import Snackbar from "@mui/material/Snackbar";
import Alert from "@mui/material/Alert";
import ItemService from "../../services/service";

const containerStyle = {
  display: "flex",
  justifyContent: "center",
  alignItems: "center",
  height: "100vh",
};

const formContainerStyle = {
  padding: "20px",
  borderRadius: "10px",
  border: "2px solid black",
  textAlign: "center",
};

const iconStyle = {
  fontSize: "48px",
  marginBottom: "10px",
};

const textFieldStyle = {
  marginBottom: "10px",
};

const buttonStyle = {
  marginTop: "10px",
};

function SignUp() {
  let [username, setUsername] = useState("");
  let [dob, setDob] = useState("");
  let [email, setEmail] = useState("");
  let [password, setPassword] = useState("");
  let [password2, setPassword2] = useState("");
  let [message, setMessage] = useState("");
  let [severity, setSeverity] = useState("");

  const navigate = useNavigate();

  const handleFormSubmit = async (e) => {
    e.preventDefault();

    try {
      if (password != password2) {
        // alert("Passwords do not match");
        throw new Error("Passwords do not match.");
      }
      let response = await ItemService.signup(username, email, dob, password);
      let data = await response.json();
      if (data.success) {
        setUsername("");
        setDob("");
        setEmail("");
        setPassword("");
        setPassword2("");
        setSeverity("success");
        setMessage(data.message);
      }
    } catch (error) {
      setSeverity("error");
      setMessage(error.message);
      console.log(error);
    }
  };

  return (
    <div style={containerStyle}>
      <div style={formContainerStyle}>
        <AccountCircleIcon style={iconStyle} />
        <form onSubmit={handleFormSubmit}>
          <TextField
            label="Username"
            value={username}
            onChange={(e) => {
              setUsername(e.target.value);
            }}
            variant="outlined"
            fullWidth
            style={textFieldStyle}
          />
          <TextField
            value={email}
            onChange={(e) => {
              setEmail(e.target.value);
            }}
            label="Email"
            type="email"
            variant="outlined"
            fullWidth
            style={textFieldStyle}
          />
          <TextField
            value={password}
            onChange={(e) => {
              setPassword(e.target.value);
            }}
            label="Password"
            type="password"
            variant="outlined"
            fullWidth
            style={textFieldStyle}
          />
          <TextField
            value={password2}
            onChange={(e) => {
              setPassword2(e.target.value);
            }}
            label="Confirm password"
            type="password"
            variant="outlined"
            fullWidth
            style={textFieldStyle}
          />
          <Button
            type="submit"
            variant="contained"
            color="primary"
            fullWidth
            style={buttonStyle}
          >
            Sign Up
          </Button>
        </form>
        <Snackbar
          open={message.length > 0}
          autoHideDuration={2000}
          onClose={(e) => {
            setMessage("");
          }}
        >
          <Alert variant="filled" severity={severity}>
            {message}
          </Alert>
        </Snackbar>
      </div>
    </div>
  );

  // return (
  //   <>
  //     <h2>Sign Up</h2>
  //     <form onSubmit={handleFormSubmit}>
  //       <div>
  //         <label>Username:</label>
  //         <input
  //           type="text"
  //           value={username}
  //           onChange={(e) => {
  //             setUsername(e.target.value);
  //           }}
  //         />
  //       </div>
  //       <div>
  //         <label>Email:</label>
  //         <input
  //           type="email"
  //           value={email}
  //           onChange={(e) => {
  //             setEmail(e.target.value);
  //           }}
  //         />
  //       </div>
  //       <div>
  //         <label>DOB:</label>
  //         <input
  //           type="date"
  //           value={dob}
  //           onChange={(e) => {
  //             setDob(e.target.value);
  //           }}
  //         />
  //       </div>
  //       <div>
  //         <label>Password:</label>
  //         <input
  //           type="password"
  //           value={password}
  //           onChange={(e) => {
  //             setPassword(e.target.value);
  //           }}
  //         />
  //       </div>
  //       <div>
  //         <label>Confirm password:</label>
  //         <input
  //           type="password"
  //           value={password2}
  //           onChange={(e) => {
  //             setPassword2(e.target.value);
  //           }}
  //         />
  //       </div>
  //       <div>
  //         <input type="submit" value={"Sign Up"} />
  //         <p>{message}</p>
  //       </div>
  //     </form>
  //   </>
  // );
}

export default SignUp;
