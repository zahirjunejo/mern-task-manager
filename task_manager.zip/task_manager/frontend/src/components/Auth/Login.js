import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";
import AccountCircleIcon from "@mui/icons-material/AccountCircle";
import ItemService from "../../services/service";

const containerStyle = {
  display: "flex",
  justifyContent: "center",
  alignItems: "center",
  height: "100vh",
};

const formContainerStyle = {
  padding: "20px",
  borderRadius: "10px",
  border: "2px solid black",
  textAlign: "center",
};

const iconStyle = {
  fontSize: "48px",
  marginBottom: "10px",
};

const textFieldStyle = {
  marginBottom: "10px",
};

const buttonStyle = {
  marginTop: "10px",
};

function Login() {
  let [username, setUsername] = useState("");
  let [password, setPassword] = useState("");

  const navigate = useNavigate();

  const handleFormSubmit = async (e) => {
    try {
      let response = await ItemService.login(username, password);
      let data = await response.json();
      if (data.success) {
        console.log("data", data);
        localStorage.setItem("token", data.token);
        navigate("/home");
        window.location.reload();
      }
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <div style={containerStyle}>
      <div style={formContainerStyle}>
        <AccountCircleIcon style={iconStyle} />
        <form>
          <TextField
            value={username}
            onChange={(e) => {
              setUsername(e.target.value);
            }}
            label="Username"
            variant="outlined"
            fullWidth
            style={textFieldStyle}
          />
          <TextField
            value={password}
            onChange={(e) => {
              setPassword(e.target.value);
            }}
            label="Password"
            type="password"
            variant="outlined"
            fullWidth
            style={textFieldStyle}
          />
          <Button
            variant="contained"
            color="primary"
            fullWidth
            style={buttonStyle}
            onClick={handleFormSubmit}
          >
            Login
          </Button>
        </form>
      </div>
    </div>
  );
}

export default Login;
