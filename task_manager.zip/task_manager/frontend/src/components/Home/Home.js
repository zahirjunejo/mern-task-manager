import React, { useEffect, useState } from "react";
import { Checkbox } from "@mui/material";
import { Edit, Delete, AddTask, Save, Cancel } from "@mui/icons-material";
import { useNavigate } from "react-router-dom";

import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import IconButton from "@mui/material/IconButton";
import TextField from "@mui/material/TextField";
import Dialog from "@mui/material/Dialog";
import DialogContent from "@mui/material/DialogContent";
import DialogTitle from "@mui/material/DialogTitle";
import Fab from "@mui/material/Fab";
import Grid from "@mui/material/Grid";
import "./Home.css";

import ItemService from "../../services/service.js";

function Home() {
  let [title, setTitle] = useState("");
  let [description, setDescription] = useState("");
  let [dueDate, setDueDate] = useState("");
  let [id, setId] = useState("");
  let [todos, setTodos] = useState([]);

  let [dateFilter, setDateFilter] = useState("");

  const [dialogOpen, setDialogOpen] = useState(false);

  const handleDialogOpen = () => {
    setDialogOpen(true);
  };

  const handleDailogClose = () => {
    setDialogOpen(false);
  };

  const navigate = useNavigate();

  useEffect(() => {
    if (!localStorage.getItem("token")) {
      navigate("/login");
      window.location.reload();
    }

    FetchTodos();
  }, []);

  const FetchTodos = async () => {
    try {
      let response = await ItemService.getTodos(dateFilter);
      let data = await response.json();
      setTodos(data.data.reverse());
      setId("");
      setTitle("");
      setDescription("");
      setDueDate("");
      setDialogOpen(false);
    } catch (error) {
      console.log(error);
    }
  };

  const EditHandler = async (todoid) => {
    try {
      let response = await ItemService.getTodosById(todoid);
      let data = await response.json();
      setDialogOpen(true);
      setId(data.data._id);
      setTitle(data.data.title);
      setDescription(data.data.description);
      setDueDate(data.data.dueDate);
    } catch (error) {
      console.log(error);
    }
  };

  const DeleteHandler = async (todoid) => {
    try {
      await ItemService.deleteTodos(todoid);
      FetchTodos();
    } catch (error) {
      console.log(error);
    }
  };

  const handleFormSubmit = async (e) => {
    e.preventDefault();

    if (!id) {
      try {
        await ItemService.createTodos({
          title: title,
          description: description,
          dueDate: dueDate,
        });

        FetchTodos();
      } catch (err) {
        console.log(err);
      }
    } else {
      try {
        await ItemService.updateTodos(id, {
          title: title,
          description: description,
          dueDate: dueDate,
        });
        FetchTodos();
      } catch (error) {
        console.log(error);
      }
    }
  };

  const handleCheckBoxChange = async (todoid, complete) => {
    try {
      await ItemService.updateTodos(todoid, {
        isComplete: !complete,
      });
      FetchTodos();
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <div>
      <React.Fragment>
        <Dialog
          fullWidth={true}
          maxWidth={"lg"}
          open={dialogOpen}
          onClose={handleDailogClose}
        >
          <DialogTitle>{id ? "Edit" : "Add"}</DialogTitle>
          <DialogContent>
            <Box
              component="form"
              onSubmit={handleFormSubmit}
              sx={{
                "& .MuiTextField-root": { m: 1, width: "25ch" },
              }}
              noValidate
              autoComplete="off"
            >
              <div>
                <TextField
                  required
                  id="outlined-required"
                  label="Title"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                />
              </div>
              <div>
                <TextField
                  id="outlined-multiline-static"
                  label="Description"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  multiline
                  rows={4}
                  style={{ width: "100%" }}
                />
              </div>
              <div>
                <TextField
                  id="outlined-number"
                  label="Due Date"
                  type="date"
                  value={dueDate}
                  onChange={(e) => setDueDate(e.target.value)}
                  InputLabelProps={{
                    shrink: true,
                  }}
                />
              </div>
              <Button variant="contained" type="submit">
                <Save fontSize="large" />
              </Button>
              <Button onClick={handleDailogClose}>
                <Cancel fontSize="large" />
              </Button>
            </Box>
          </DialogContent>
        </Dialog>
      </React.Fragment>
      <div className="grid-container">
        <Grid container spacing={2}>
          {todos.map((todo) => (
            <Grid item key={todo._id} xs={12} sm={6} md={4}>
              <div
                style={{
                  maxWidth: "400px",
                }}
              >
                <img
                  src="http://localhost:3000/public/test.jpg"
                  alt="Sample"
                  className="zoomable-image"
                />
                <div
                  style={{
                    margin: "0",
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                  }}
                >
                  <h3
                    style={{
                      margin: "0",
                      textTransform: "uppercase",
                      fontSize: "small",
                    }}
                  >
                    {todo.title}
                  </h3>
                  <span>
                    Complete?
                    <Checkbox
                      size="small"
                      checked={todo.isComplete}
                      onChange={(e) => {
                        handleCheckBoxChange(todo._id, todo.isComplete);
                      }}
                      inputProps={{ "aria-label": "controlled" }}
                      sx={{
                        color: "blue",
                        "&.Mui-checked": {
                          color: "blue",
                        },
                      }}
                    />
                  </span>
                </div>

                <div
                  style={{ display: "flex", justifyContent: "space-between" }}
                >
                  <p
                    style={{
                      margin: "0",
                      flex: "1",
                      textTransform: "uppercase",
                      fontSize: "small",
                    }}
                  >
                    {todo.description}
                  </p>
                  <p
                    style={{
                      color: "#888",
                      margin: "0",
                      marginLeft: "10px",
                      fontSize: "small",
                    }}
                  >
                    {todo.dueDate}
                  </p>
                </div>
                <div style={{ display: "flex", alignItems: "center" }}>
                  <IconButton
                    color="primary"
                    onClick={(e) => {
                      EditHandler(todo._id);
                    }}
                  >
                    <Edit fontSize="small" />
                  </IconButton>
                  <IconButton
                    color="error"
                    onClick={(e) => {
                      DeleteHandler(todo._id);
                    }}
                  >
                    <Delete fontSize="small" />
                  </IconButton>
                </div>
              </div>
            </Grid>
          ))}
        </Grid>
      </div>

      <Fab
        color="primary"
        onClick={handleDialogOpen}
        sx={{ position: "fixed", bottom: "5vh", right: "5vw" }}
      >
        <AddTask fontSize="large" />
      </Fab>
    </div>
  );
}

export default Home;
