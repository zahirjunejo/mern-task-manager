const ItemService = {
  getTodos: (dateFilter) => {
    let url = `http://localhost:3000/private/todo`;
    if (dateFilter !== "") {
      url = `${url}?duedate=${dateFilter}`;
    }

    return fetch(url, {
      method: "GET",
      headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
    });
  },
  getTodosById: (id) =>
    fetch(`http://localhost:3000/private/todo/${id}`, {
      method: "GET",
      headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
    }),
  createTodos: (body) =>
    fetch("http://localhost:3000/private/todo", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${localStorage.getItem("token")}`,
      },
      body: JSON.stringify(body),
    }),
  updateTodos: (id, body) =>
    fetch(`http://localhost:3000/private/todo/${id}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${localStorage.getItem("token")}`,
      },
      body: JSON.stringify(body),
    }),
  deleteTodos: (id) =>
    fetch(`http://localhost:3000/private/todo/${id}`, {
      method: "DELETE",
      headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
    }),
  login: (username, password) =>
    fetch("http://localhost:3000/public/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        userName: username,
        password: password,
      }),
    }),
  signup: (username, email, dob, password) =>
    fetch("http://localhost:3000/public/signup", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        userName: username,
        email: email,
        dob: dob,
        password: password,
      }),
    }),
};

export default ItemService;
