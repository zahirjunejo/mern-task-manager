import logo from "./logo.svg";
import "./App.css";
import { Route, Link, Routes } from "react-router-dom";
import { List, LoginRounded, Logout, PersonAdd } from "@mui/icons-material";
import { useNavigate } from "react-router-dom";

// import About from "./About";
import SignUp from "./components/Auth/SignUp";
import Login from "./components/Auth/Login";
import Home from "./components/Home/Home";
import { Button } from "@mui/material";

function App({ appTitle }) {
  const navigate = useNavigate();
  return (
    <div>
      <header className="App-header">
        <div className="App-header-left">
          {appTitle}
          {localStorage.getItem("token") && (
            <Button
              onClick={(e) => {
                navigate("/home");
              }}
            >
              <List color="success" fontSize="medium" />
            </Button>
          )}
        </div>
        <div className="App-header-right">
          {localStorage.getItem("token") && (
            <Button
              onClick={(e) => {
                e.preventDefault();
                localStorage.clear();
                window.location.reload();
              }}
            >
              <Logout color="error" fontSize="medium" />
            </Button>
          )}
          {!localStorage.getItem("token") && (
            <span>
              {
                <Button
                  onClick={(e) => {
                    navigate("/sign-up");
                  }}
                >
                  <PersonAdd fontSize="medium" />
                </Button>
              }
              {!localStorage.getItem("token") && (
                <Button
                  onClick={(e) => {
                    navigate("/login");
                  }}
                >
                  <LoginRounded fontSize="medium" />
                </Button>
              )}
            </span>
          )}
        </div>
      </header>
      <Routes>
        <Route path="/" Component={Login} />
        <Route path="/home" Component={Home} />
        <Route path="/sign-up" Component={SignUp} />
        <Route path="/login" Component={Login} />
      </Routes>
    </div>
  );
}

export default App;
