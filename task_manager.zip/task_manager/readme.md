This project has two parts.
Frontend and Backend.
The frontend can be run by typing `npm start`
To run the backend type `npm run watch`
Make sure to run `npm install` in both backend and frontend

## Backend

MongoDB schema files are in the models folder.
All the routes are in the router-private and router-public
JWT authentication is used here.

## Frontend

Used fetch api to pass API requests. login and register form is a bit undesigned while main route is completely designed.
Used react material ui for design.

## Features

Before you start using the app you need to sign up first by clicking on the top right. Fill up the details and sign up.

After that your account is created, you can then login using the login button on the top right.

In the main UI use the add button on the bottom right to add a new task. To edit a task click on the pencil icon on the task card. To delete a task click the trash icon button on the task card. To mark a task as complete, click on the check box.
