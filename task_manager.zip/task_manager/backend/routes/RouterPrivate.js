const router = require(`express`).Router()

const authentication = require('../middleware/validateJWT')
const tokenMW = require('../middleware/token-helper')
const todoModel = require('../models/Todos')

module.exports = function RouterPrivate() {
  router.use(tokenMW.setToken)
  router.use(authentication.authenticate)

  router.get('/heartbeat', (req, res) => {
    res.send('All ok')
  })

  router.get('/todo', async (req, res) => {
    // Get all the todos

    try {
      let filter = { userId: req.user._id }
      if (req.query.complete) {
        filter['isComplete'] = req.query.complete
      }

      if (req.query.duedate) {
        filter['dueDate'] = { $regex: req.query.duedate, $options: 'i' }
      }

      let todos = await todoModel.find(filter)

      return res.status(200).json({ data: todos })
    } catch (err) {
      return res.status(502).json({ error: err.message })
    }
  })

  router.get('/todo/:id', async (req, res) => {
    // Get a specific todo
    try {
      let todo = await todoModel.findById(req.params.id)
      return res.status(200).json({ data: todo })
    } catch (err) {
      return res.status(502).json({ error: err.message })
    }
  })

  router.post('/todo', async (req, res) => {
    // To create a todo

    try {
      let title = req.body.title
      let description = req.body.description
      let dueDate = req.body.dueDate
      let userId = req.user._id
      const new_todo = new todoModel({
        title: title,
        description: description,
        dueDate: dueDate,
        isComplete: false,
        userId: userId,
      })
      await new_todo.save()
      return res.status(200).json({ data: new_todo })
    } catch (ex) {
      return res.status(502).json({ error: ex.message })
    }
  })

  router.put('/todo/:id', async (req, res) => {
    // To update a todo
    try {
      let todo = await todoModel.findById(req.params.id)

      todo.title = req.body.title ?? todo.title
      todo.description = req.body.description ?? todo.description
      todo.dueDate = req.body.dueDate ?? todo.dueDate
      todo.isComplete = req.body.isComplete ?? todo.isComplete
      todo.userId = req.body.userId ?? todo.userId

      await todo.save()

      return res.status(200).json({ data: todo })
    } catch (err) {
      return res.status(502).json({ error: err.message })
    }
  })

  router.delete('/todo/:id', async (req, res) => {
    // To delete a todo
    try {
      let todo = await todoModel.deleteOne({ _id: req.params.id })
      return res.status(200).json({ success: true, data: todo })
    } catch (err) {
      return res.status(502).json({ success: false, error: err.message })
    }
  })

  return router
}
