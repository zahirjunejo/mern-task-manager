const router = require('express').Router()
const usersModel = require('../models/User')
const bcrypt = require(`bcryptjs`)
const jwt = require(`jsonwebtoken`)
const config = require(`../server-settings.json`)

module.exports = function RouterPublic() {
  router.get('/heartbeat', (req, res) => {
    res.send('All ok')
  })

  router.post('/signup', async (req, res) => {
    try {
      const new_user = new usersModel({
        userName: req.body.userName,
        email: req.body.email,
        DOB: req.body.dob,
        password: req.body.password,
      })

      await new_user.save()
      return res.status(200).json({
        success: true,
        data: new_user,
        message: 'User creation successful!',
      })
    } catch (ex) {
      return res.status(502).json({ success: false, error: ex })
    }
  })

  router.post('/login', async (req, res) => {
    try {
      let user = await usersModel.findOne({ userName: req.body.userName })
      let isMatch = await bcrypt.compare(req.body.password, user.password)

      if (!isMatch) {
        throw 'Username not found or password did not match'
      }

      const token = jwt.sign({ sub: user._id }, config.server.secret, {
        algorithm: 'HS512',
      })

      return res.status(200).json({
        success: true,
        message: 'Login success!',
        token: token,
      })
    } catch (err) {
      return res.status(502).json({ success: false, message: err.message })
    }
  })

  return router
}
