const mongoose = require('mongoose')
let { Schema } = mongoose
const userSchema = new Schema({
  userName: { type: String, required: true, unique: true },
  email: {
    type: String,
    required: true,
    unique: true,
    match: [
      /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/,
      'Please fill a valid email address',
    ],
  },
  DOB: { type: String, required: false },
  password: { type: String, required: true },
})

const bcrypt = require(`bcrypt-nodejs`)
userSchema.pre(`save`, function (callback) {
  const user = this

  user.updated = new Date(Date.now())

  // Break if the pass hasn't been modified
  if (!user.isModified(`password`)) return callback()

  // Password changed so we need to hash it before storing on database
  bcrypt.genSalt(5, (err, salt) => {
    if (err) return callback(err)

    // eslint-disable-next-line no-shadow
    bcrypt.hash(user.password, salt, null, (err, hash) => {
      if (err) return callback(err)
      user.password = hash
      callback()
    })
  })
})

const model = mongoose.model('User', userSchema)

module.exports = model
