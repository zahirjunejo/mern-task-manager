const mongoose = require('mongoose')
let { Schema } = mongoose
const todoSchema = new Schema({
  title: { type: String, required: true },
  description: { type: String, required: true },
  dueDate: { type: String, required: true },
  isComplete: { type: Boolean },
  userId: { type: Schema.Types.ObjectId },
})

const model = mongoose.model('Todo', todoSchema)

module.exports = model
