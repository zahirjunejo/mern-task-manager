const express = require('express')
const mongoose = require('mongoose')
const bodyParser = require('body-parser')
const path = require('path')

let cors = require('cors')

const app = express()
app.use('/public', express.static(path.join(__dirname, 'public')))
app.use(cors())

// Custom Middleware: Logging
const logMiddleware = (req, res, next) => {
  console.log(`[${new Date().toISOString()}] ${req.method} ${req.url}`)
  next() // Move on to the next middleware or route handler
}

app.use(logMiddleware)

app.get('/', (req, res) => {
  res.send('Hello, Express!')
})
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({ extended: false }))

const port = process.env.PORT || 3000

require(`dotenv`).config()

process.env.NODE_ENV !== `development` && (console.log = () => null)

const RouterPublic = require('./routes/RouterPublic')()
const RouterPrivate = require('./routes/RouterPrivate')()

app.use('/private', RouterPrivate)
app.use('/public', RouterPublic)

// Dev error handler -- to print stack trace
if (app.get(`env`) === `development`) {
  app.use((err, req, res, next) => {
    res.status(err.status || 500)
    res.json({ message: err.message, error: err })
  })
}

// Production error handler -- no stack traces
// leaked to user
app.use((err, req, res, next) => {
  res.status(err.status || 404)
  res.send()
})

app.use((req, res, next) => {
  const err = new Error(`Not Found`)

  err.status = 404

  res.json(err)

  next(err)
})

async function main() {
  console.log('Connecting to MongoDB...')
  await mongoose.connect('mongodb://127.0.0.1:27017/tododb')
}

main()
  .then(() => {
    console.log('Connected to MongoDB')
  })
  .catch((err) => {
    console.log(err)
  })

app.listen(port, () => {
  console.log(`Server is listening at port ${port}`)
})
